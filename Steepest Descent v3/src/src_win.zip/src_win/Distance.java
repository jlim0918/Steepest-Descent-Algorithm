// header file
import java.io.*;

public class Distance {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		// variables
		double speed, time, dist;

		// object to read user input at command line
		BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));
		
		// get the speed
		System.out.print("Enter a speed (miles/hour): ");
		speed = Double.parseDouble(cin.readLine());
		
		// get the time
		System.out.print("Enter a time traveled (minutes): ");
		time = Double.parseDouble(cin.readLine());
		
		// calculate distance and print to screen
		dist = speed*time/60.0;
		System.out.format("The distance traveled is %.3f miles.\n", dist);
		
	} // end of main function
	
} // end of class
