import java.io.*;

public class PrintMenuFn {

	public static void main(String[] args) throws IOException, NumberFormatException {
		int choice;
		BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));
		do {
			printMenu();
			choice = Integer.parseInt(cin.readLine());
			
			if (choice == 1) {
				// do things
			}
			else if (choice == 2) {
				// do other things
			}
			else if (choice != 0) {
				System.out.println("ERROR: Invalid menu choice!\n");
			}
		} while (choice != 0);
	} // end main
	
	// print the menu
	public static void printMenu() {
		System.out.println("  MY JAVA PROGRAM");
		System.out.println("0 - Quit");
		System.out.println("1 - Option 1");
		System.out.println("2 - Option 2");
		System.out.print("\nEnter choice: ");
	}
}
