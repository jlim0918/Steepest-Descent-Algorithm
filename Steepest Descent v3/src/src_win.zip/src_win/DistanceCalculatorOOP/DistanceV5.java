public class DistanceV5 {
	
	public static void main(String[] args) {
		
		DistanceCalculator dc = new DistanceCalculator();
		dc.getUserInput();
		dc.printDistance();
		
	} // end of main function
		
} // end of class
