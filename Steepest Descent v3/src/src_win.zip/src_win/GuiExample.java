import java.awt.*;      
import javax.swing.*;

public class GuiExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(300, 300));
        frame.setTitle("A tale of two buttons");
        
        // Where is did this button go?
        JButton button1 = new JButton();
        button1.setText("I'm a button.");
        button1.setBackground(Color.BLUE);
        button1.setOpaque(true);    // force opacity; needed for Mac
        frame.add(button1);

        JButton button2 = new JButton();
        button2.setText("Click me!");
        button2.setBackground(Color.RED);
        button2.setOpaque(true);    // force opacity; needed for Mac
        frame.add(button2);

        frame.setVisible(true);
    }
}
