import java.awt.*;      
import javax.swing.*;

public class GuiBorderLayout {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(400, 200));
        frame.setTitle("BorderLayout");
        
        frame.setLayout(new BorderLayout());
        frame.add(new JButton("Button 1"), BorderLayout.NORTH);
        frame.add(new JButton("Button 2"), BorderLayout.WEST);
        frame.add(new JButton("Button 3"), BorderLayout.CENTER);
        frame.add(new JButton("Button 4"), BorderLayout.EAST);
        frame.add(new JButton("Long-named Button 5"), BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}
