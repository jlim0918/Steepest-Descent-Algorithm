import java.awt.*;      
import javax.swing.*;

public class GuiBoxLayout {
 
    public static void main(String[] args) {
        JFrame frame = new JFrame("BoxLayout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JButton button1 = new JButton("Button 1");
        JButton button2 = new JButton("2");
        JButton button3 = new JButton("Button 3");
        JButton button4 = new JButton("Long-named Button 4");
        
        JPanel panel1 = new JPanel();
        JPanel panel2 = new JPanel();
        panel1.setBorder(BorderFactory.createTitledBorder("LEFT"));
        panel2.setBorder(BorderFactory.createTitledBorder("RIGHT"));
        panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));
        panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
        
        panel1.add(button1);
        panel1.add(button2);
         
        button3.setAlignmentX(Component.RIGHT_ALIGNMENT);
        button4.setAlignmentX(Component.RIGHT_ALIGNMENT);
        panel2.add(button3);
        panel2.add(button4);
         
        frame.setLayout(new FlowLayout());
        frame.add(panel1);
        frame.add(panel2);
        
        frame.pack();
        frame.setVisible(true);
    }
}
