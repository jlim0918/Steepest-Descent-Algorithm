public class NumProbs {

	public static void main(String[] args) {
		// double overflow = infinity
		double x = 1e300, y = 1e300;
		double z = x*y;
		System.out.println(x + " x " + y + " = " + z);
		
		// integer overflow wraps around
		int i = Integer.MAX_VALUE; // 2147483647
		int j = i + 1;
		System.out.println(i + " + 1 = " + j);
		
		// underflow = 0.0
		double u = 1e-200;
		double v = u*u;
		System.out.println(u + " x " + u + " = " + v);
		
		// truncation
		double t = 1e20;
		double w = t + 10;
		System.out.println(t + " + 10 = " + w);
		
		// round-off error (representation error)
		x = 0.2 + 0.2 + 0.2;
		if (x == 0.6) System.out.println("Exactly equal");
        else if (Math.abs(x-0.6) < 1e-4) System.out.println("Close enough");
		else System.out.println("Not exactly equal");
	}
}
