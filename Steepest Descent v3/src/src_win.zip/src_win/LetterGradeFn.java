import java.io.*;

public class LetterGradeFn {

	public static void main(String[] args) throws IOException, NumberFormatException {
		double num;
		char letter;
		BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("Enter numerical grade: ");
		num = Double.parseDouble(cin.readLine());
		
		letter = getLetterGrade(num);
		
		System.out.format("%.2f -> %s\n", num, letter);

	} // end main
	
	// transform a numerical score into a letter grade
	public static char getLetterGrade(double score) {
		if (score < 50) return 'F';
		if (score < 60) return 'D';
		if (score < 70) return 'C';
		if (score < 80) return 'B';
		else return 'A';
	}
}
