import java.io.*;
public class DistanceV3 {
	
	public static BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));

	public static void main(String[] args) {
		double speed = getNonnegDouble();
		double time = getNonnegDouble();
		
		System.out.format("The distance traveled is %.3f miles.\n", speed*time/60.0);
	} // end of main function
	
	// get a non-negative double from the user
	public static double getNonnegDouble() {
		double x = 0;
		boolean valid;
		do {
			valid = true;
			try {
				x = Double.parseDouble(cin.readLine());
			} 
			catch (NumberFormatException e) {
				System.out.println("ERROR: Number format exception!\n");
				valid = false;
			} 
			catch (IOException e) {
				System.out.println("ERROR: IO exception!\n");
				valid = false;
			}
			if (valid && x < 0) {
				valid = false;
				System.out.println("ERROR: Value must be non-negative!\n");
			}
		} while (!valid);
		return x;
	} // end of getNonnegDouble()
		
} // end of class
