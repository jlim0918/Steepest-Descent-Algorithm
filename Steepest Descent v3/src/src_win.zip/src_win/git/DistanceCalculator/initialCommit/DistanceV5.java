import java.io.*; // Needed for exception handling

public class DistanceV5 {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		DistanceCalculator dc = new DistanceCalculator();
		dc.getUserInput();
		dc.printDistance();
		
	} // end of main function
		
} // end of class
