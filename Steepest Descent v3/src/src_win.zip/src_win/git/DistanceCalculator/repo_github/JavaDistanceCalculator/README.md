# JavaDistanceCalculator
A Java DistanceCalculator OOP for GitHub demonstration
