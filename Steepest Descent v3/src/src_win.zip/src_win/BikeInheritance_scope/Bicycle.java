public class Bicycle {
	private int numGears;
	private double price;

	public Bicycle() { 
		this.numGears = 0; 
		this.price = 0.0; 
	}
	
	public double getPrice() { return this.price; }
	public void setPrice(double price) { this.price = price; }
	public int getGears() { return this.numGears; }
	public void setGears(int numGears) { this.numGears = numGears; }

	public void rideTheMountain() { 
		System.out.println("Popped a tire."); 
	}
}


