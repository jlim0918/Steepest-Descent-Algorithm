public class PermComb {
	
	public static void main(String[] args) {
		System.out.println("10 P 3 = " + permutation(10, 3));
		System.out.println("10 C 3 = " + combination(10, 3));
	} // end of main function
	
	// permutation n P r: n! / (n-r)!
	public static int permutation(int n, int r) {
		return factorial(n) / factorial(n-r);
	}
	
	public static int permutationV2(int n, int r) {
		int perm = 1;
		for (int i = n-r+1; i <= n; i++) perm *= i;
		return perm;
	}
	
	// combination n C r: n! / (r!(n-r)!)
	public static int combination(int n, int r) {
		return factorial(n) / ( factorial(r) * factorial(n-r) );
	}
	
	public static int combinationV2(int n, int r) {
		int comb = permutationV2(n,r);
		for (int i = 2; i <= r; i++)  comb /= i;
		return comb;
	}

	public static int factorial(int f) {
		int nfact = 1;
		for (int k = 2; k <= f; k++) nfact *= k;
		return nfact;
	}
} // end of class
