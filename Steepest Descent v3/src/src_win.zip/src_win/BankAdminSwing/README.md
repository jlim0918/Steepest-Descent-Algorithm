# Bank Administration System

Program execution begins in src/Application.java. To compile and run by command line:

javac Application.java
java Application

Source code files are organized in directories according to their content. All are compiled automatically when the main source file is compiled. Note the use of import statements to import additional source files.

# Login credentials

username: admin
password: admin
