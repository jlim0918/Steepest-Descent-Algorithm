import java.awt.*;      
import javax.swing.*;

public class GuiGridBagLayout {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(400, 120));
        frame.setTitle("GridBagLayout");
        
        frame.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        frame.add(new JButton("Button 1"), gbc);
        
        gbc.gridx = 1;
        frame.add(new JButton("2"), gbc);
        
        gbc.gridx = 2;
        frame.add(new JButton("Button 3"), gbc);
        
        gbc.gridwidth = 3;
        gbc.gridx = 0;
        gbc.gridy = 1;
        frame.add(new JButton("Long-named Button 4"), gbc);
        
        gbc.gridx = 2;
        gbc.gridy = 2;
        frame.add(new JButton("Button 5"), gbc);

        frame.setVisible(true);
    }
}
