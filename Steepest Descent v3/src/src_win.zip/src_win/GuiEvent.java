import java.awt.*;      
import javax.swing.*;
import java.awt.event.*;

public class GuiEvent {
    private JFrame frame;
    private JButton stutter;
    private JTextField textfield;

    public GuiEvent() {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(400, 100));
        frame.setTitle("Double the text");
        frame.setLayout(new FlowLayout());
        
        textfield = new JTextField("A", 20);
        frame.add(textfield);
        
        stutter = new JButton("Double it");
        stutter.addActionListener(new StutterListener());
        frame.add(stutter);
        
        frame.setVisible(true);
    }

    // When button is clicked, doubles the field's text.
    private class StutterListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            String text = textfield.getText();
            textfield.setText(text + text);
        }
    }
    
    public static void main(String[] args) {
        new GuiEvent(); // creates an object just to invoke constructor
    }
}
