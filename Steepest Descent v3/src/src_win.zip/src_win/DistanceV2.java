import java.io.*;
public class DistanceV2 {
	public static void main(String[] args) throws NumberFormatException, IOException {

		double speed = 0, time = 0, dist;
		boolean valid;

		BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));
		
		// get a valid speed
		do {
			valid = true;
			System.out.print("Enter a speed (miles/hour): ");
			try {
				speed = Double.parseDouble(cin.readLine());
			} 
			catch (NumberFormatException e) {
				System.out.println("ERROR: Number format exception!\n");
				valid = false;
			} 
			catch (IOException e) {
				System.out.println("ERROR: IO exception!\n");
				valid = false;
			}
			
			if (valid && speed < 0) {
				valid = false;
				System.out.println("ERROR: Value must be non-negative!\n");
			}
		} while (!valid);
		
		System.out.print("Enter a time traveled (minutes): ");
		time = Double.parseDouble(cin.readLine());
		dist = speed * time / 60.0;
		System.out.format("The distance traveled is %.3f miles.\n", dist);
	} // end of main function
} // end of class
