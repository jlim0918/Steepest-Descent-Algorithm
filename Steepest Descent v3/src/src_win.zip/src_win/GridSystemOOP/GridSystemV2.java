
public class GridSystemV2 {

	public static void main(String[] args) {
		Point p1 = new Point();
		Point p2 = new Point(2,2);
		
		System.out.print("Point p1: ");
		p1.print();
		System.out.print("Point p2: ");
		p2.print();
		
		p1.moveto(1,3);
		System.out.print("Now point p1 is ");
		p1.print();
		
		p2.move(0.5,0.1);
		System.out.print("Now point p2 is ");
		p2.print();
		
		System.out.print("Of (" + p1.getX() + "," + p1.getY() + ") " +
				"and (" + p2.getX() + "," + p2.getY() + "), ");
		if (p1.fromOrigin() < p2.fromOrigin()) System.out.print("p1");
		else System.out.print("p2");		
		System.out.println(" is closer to the origin.");
		
	}
}


