
public class GridSystemV3 {

	public static void main(String[] args) {
		double s = 2.0;
		Point p1 = new Point(2,0);
		Point p2 = new Point(4,2);
		Point p3 = new Point(1,1);
		
		Line a = new Line(p1,p2);	// create a line with two points
		Line b = new Line(p2,s);	// create a line with a point and slope
		
		System.out.println("On line a, y = 5 occurs at x = " + a.getX(5));
		System.out.println("On line a, x = 5 occurs at y = " + a.getY(5));
		System.out.println("The intercept of line a is " + a.intercept());
		System.out.println("The root of line a is " + a.root());
		System.out.println("The intercept of line b is " + b.intercept());
		
		System.out.print("Point p3: ");
		p3.print();
		if (a.isOnTheLine(p3)) System.out.println("   is on line a.");
		else System.out.println("   is not on line a.");
	}
}


