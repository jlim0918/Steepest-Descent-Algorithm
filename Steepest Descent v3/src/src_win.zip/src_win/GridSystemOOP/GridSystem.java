public class GridSystem {

	public static void main(String[] args) {
		Point p1 = new Point();
		Point p2 = new Point(4,5);
		
		System.out.print("Point p1: ");
		p1.print();
		
		System.out.print("Point p2: ");
		p2.print();
		
		p1 = p2;
		System.out.print("New point p1: ");
		p1.print();
	}

}
