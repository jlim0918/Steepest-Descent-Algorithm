
public class Line {
	private Point p;
	private double slope;
	
	public Line(Point p1, double s) {
		p = p1;
		slope = s;
	}
	
	public Line(Point p1, Point p2) {
		p = p1; // or p = p2;
		slope = (p1.getY()-p2.getY())/(p1.getX()-p2.getX());
	}
	
	public double getY(double x) { return slope*x + intercept(); }
	
	public double getX(double y) { return (y - intercept())/slope; }
	
	public double intercept() { return p.getY() - slope*p.getX(); }
	
	public double root() { return -1*intercept()/slope; }
	
	public boolean isOnTheLine(Point p1) { 
		return slope == (p1.getY()-p.getY())/(p1.getX()-p.getX());
	}
}

