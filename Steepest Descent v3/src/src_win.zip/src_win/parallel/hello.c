#include <stdio.h>
#include <mpi.h>	// the MPI library

int main(int argc, char **argv) {
	int proc, size;
   
	// initialize the MPI environment
	MPI_Init(&argc, &argv);
	
	// get the size of the processor pool
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	
	// get this processor's rank (number)
	MPI_Comm_rank(MPI_COMM_WORLD, &proc);
	
	// say hi
	printf("Hello World, from Processor %d of %d\n", proc, size);
            
	// end the MPI environment
	MPI_Finalize();

	return 0;
}
