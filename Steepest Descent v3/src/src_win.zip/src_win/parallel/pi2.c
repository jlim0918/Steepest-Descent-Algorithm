#include <stdio.h> 
#include <stdlib.h>
#include <math.h> 
#include <mpi.h>
#define MASTER 0

int main(int argc, char *argv[]) { 
    int n = -1, rank, size, i; 
    double PI25DT = 3.141592653589793238462643; 
    double mypi, pi, h, sum, t; 
    MPI_Init(&argc, &argv); 
    MPI_Comm_size(MPI_COMM_WORLD, &size); 
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); 
	
	if (rank == MASTER) { 
		n = atoi(argv[1]);
	} 
	MPI_Bcast(&n, 1, MPI_INT, MASTER, MPI_COMM_WORLD); 
	if (n != 0) { 
		h = 1.0 / (double) n; 
		sum = 0.0; 
		for (i = rank + 1; i <= n; i += size) { 
			t = h * ((double)i - 0.5); 
			sum += (4.0 / (1.0 + t*t)); 
		} 
		mypi = h * sum; 
		MPI_Reduce(&mypi, &pi, 1, MPI_DOUBLE, MPI_SUM, MASTER, MPI_COMM_WORLD); 
		if (rank == MASTER)  
			printf("pi is approximately %.16f, Error is %.16f\n", pi, fabs(pi - PI25DT)); 
	} 
    MPI_Finalize(); 

	return 0;
}
