#include <stdio.h>
#include <mpi.h>	// the MPI library
#define MASTER 0	// a constant to identify the master

int main (int argc, char **argv) {
	const int channel = 1;	// Communication channel
	int rank, size;
	int nSims = 100;
	int startSim = 0, endSim = 0, startProc = 1, i;
	
	MPI_Init(&argc, &argv); 
	MPI_Comm_size(MPI_COMM_WORLD, &size); 
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	size--;	// Why?
	
	if (rank == MASTER) {	// this is the master
		int chunksize = (int)nSims/size;
		int remainder = nSims%size;
		
		printf("Number of processors: %d\n", size);
		printf("Chunk size: %d\n", chunksize);
		printf("Remainder: %d\n", remainder);

		for (i = 1; i <= size; i++) {
			startSim = endSim;
			endSim = startSim + chunksize - 1;
			if (i <= remainder) 
				endSim++;
			MPI_Send(&startSim, 1, MPI_INT, i, channel, MPI_COMM_WORLD);
			MPI_Send(&endSim, 1, MPI_INT, i, channel, MPI_COMM_WORLD);
			endSim++;
		}
	}
	else {	// this is a slave
		MPI_Recv(&startSim, 1, MPI_INT, MASTER, channel, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		MPI_Recv(&endSim, 1, MPI_INT, MASTER, channel, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		printf("Processor %d of %d assigned simulations %d-%d\n",rank,size,startSim,endSim);
	}
	MPI_Finalize(); // shut down MPI

	return 0;
}
