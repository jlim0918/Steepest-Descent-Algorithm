public class RoadBike extends Bicycle {
	
	@Override
	public void rideTheMountain() {
		System.out.println("Severe damage sustained.");
	}
	
}
