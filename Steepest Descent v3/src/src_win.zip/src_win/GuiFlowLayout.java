import java.awt.*;      
import javax.swing.*;

public class GuiFlowLayout {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(400, 100));
        frame.setTitle("FlowLayout");
        
        frame.setLayout(new FlowLayout());
        frame.add(new JButton("Button 1"));
        frame.add(new JButton("2"));
        frame.add(new JButton("Button 3"));
        frame.add(new JButton("Long-named Button 4"));
        frame.add(new JButton("Button 5"));

        frame.setVisible(true);
    }
}
